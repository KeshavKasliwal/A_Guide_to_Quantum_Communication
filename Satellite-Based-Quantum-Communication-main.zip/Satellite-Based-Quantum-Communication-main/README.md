# Satellite-Based-Quantum-Communication
## This includes the codes for different protocols being utilized on a satellite-to-ground link communication
## Also, it includes the analysis of different types of losses as well
