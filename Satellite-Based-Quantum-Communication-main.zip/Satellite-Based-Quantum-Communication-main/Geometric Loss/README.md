# Geometric Loss
## Geometric loss, or diffraction loss, refers to the loss due to the beam spread effect when it propagates from the satellite to the optical ground station.
## This covers the MATLAB codes for Geometric Loss vs different parameters. 
