# Optical_Fiber_Quantum_Communication
## This contains the MATLAB codes and simulation results for Optical Fiber Quantum Communication for various protocols.
